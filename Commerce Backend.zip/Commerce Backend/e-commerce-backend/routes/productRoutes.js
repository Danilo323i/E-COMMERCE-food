const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const upload = require('../config/multerConfig');

router.get('/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).json(products);
    } catch (error) {
        console.error('Error fetching products:', error.message);
        res.status(500).json({ message: 'Error fetching products', error: error.message });
    }
});

router.post('/upload', upload.single('image'), (req, res) => {
    try {
        const imageUrl = req.file.path;
        res.status(200).json({ imageUrl });
    } catch (error) {
        console.error('Error uploading image:', error.message);
        res.status(500).json({ message: 'Error uploading image', error: error.message });
    }
});

module.exports = router;
